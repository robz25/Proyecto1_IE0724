#include "hello_world.h"

int main(){
    int status = 0;
    status = hello_world(5);
    return status;
}
